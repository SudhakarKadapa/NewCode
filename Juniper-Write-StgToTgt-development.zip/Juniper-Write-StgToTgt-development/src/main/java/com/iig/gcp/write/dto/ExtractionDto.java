package com.iig.gcp.write.dto;




public class ExtractionDto {
	
	
	FeedDto feedDto;
	TargetDto targetDto;
	String encryption_flag;
	
	
	
	
	public String getEncryption_flag() {
		return encryption_flag;
	}
	public void setEncryption_flag(String encryption_flag) {
		this.encryption_flag = encryption_flag;
	}
	
	
	
	public TargetDto getTargetDto() {
		return targetDto;
	}
	public void setTargetDto(TargetDto targetDto) {
		this.targetDto = targetDto;
	}
	public FeedDto getFeedDto() {
		return feedDto;
	}
	public void setFeedDto(FeedDto feedDto) {
		this.feedDto = feedDto;
	}
	

}
