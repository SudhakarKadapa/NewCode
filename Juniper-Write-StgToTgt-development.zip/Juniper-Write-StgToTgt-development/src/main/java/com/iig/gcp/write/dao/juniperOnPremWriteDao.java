package com.iig.gcp.write.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import com.iig.gcp.write.constant.MetadataDBConstants;
import com.iig.gcp.write.dto.ExtractionDto;
import com.iig.gcp.write.dto.FeedDto;
import com.iig.gcp.write.dto.TargetDto;
import com.iig.gcp.write.util.EncryptUtils;


public class juniperOnPremWriteDao {
	
	
	public static  TargetDto getTargetObject(Connection conn,String target) throws Exception{

		Statement statement=conn.createStatement();
		String query="";
		ResultSet rs;
		TargetDto targetDto=new TargetDto();
		
		try {
				
				query=" select target_type,gcp_sequence,hdp_knox_host,hdp_knox_port,hdp_user,hdp_encrypted_password,encrypted_key,hdp_hdfs_path,hdfs_gateway,partition_flag,materialization_flag,target_conn_sequence from "+MetadataDBConstants.TARGETTABLE
						+ " where target_unique_name='"+target+"'";
				rs = statement.executeQuery(query);
				if(rs.isBeforeFirst()) {
					rs.next();
					if(rs.getString(1).equalsIgnoreCase("gcs")) {
						
						targetDto.setTarget_type(rs.getString(1));
						int gcp_seq=Integer.parseInt(rs.getString(2));
						String query2="select gcp_project,bucket_name,service_account_name from "+MetadataDBConstants.GCPTABLE+" where gcp_sequence="+gcp_seq;
						Statement statement2=conn.createStatement();
						ResultSet rs2=statement2.executeQuery(query2);
						if(rs2.isBeforeFirst()) {
							rs2.next();
							targetDto.setTarget_project(rs2.getString(1));
							targetDto.setTarget_bucket(rs2.getString(2));
							targetDto.setService_account(rs2.getString(3));
						}
						targetDto.setTarget_id(Integer.parseInt(rs.getString(12)));

					}
					if(rs.getString(1).equalsIgnoreCase("hdfs")) {
						
						targetDto.setTarget_type(rs.getString(1));
						targetDto.setTarget_knox_host(rs.getString(3));
						targetDto.setTarget_knox_port(Integer.parseInt(rs.getString(4)));
						targetDto.setTarget_user(rs.getString(5));
						targetDto.setEncrypted_password(rs.getBytes(6));
						targetDto.setEncrypted_key(rs.getBytes(7));
						targetDto.setTarget_hdfs_path(rs.getString(8));
						targetDto.setTarget_hdfs_gateway(rs.getString(9));
						targetDto.setPartition_flag(rs.getString(10));
						targetDto.setMaterialization_flag(rs.getString(11));
						targetDto.setTarget_id(Integer.parseInt(rs.getString(12)));
						String password=EncryptUtils.decyptPassword(targetDto.getEncrypted_key(), targetDto.getEncrypted_password());
						targetDto.setTarget_password(password);
					}
					
					
					
				}
		}catch(SQLException e) {
			e.printStackTrace();
			throw new Exception("Exception occured while retrieving target information");
		}

		return targetDto;
	}
	
	
	public static FeedDto getFeedObject(Connection conn,String feed_name) throws Exception {
		
		
		FeedDto feedDto=new FeedDto();
		String query="select feed_sequence,feed_unique_name,country_code,project_sequence from "+MetadataDBConstants.FEEDTABLE
				+ " where feed_unique_name='"+feed_name+"'";
		

		try {
			Statement statement=conn.createStatement();
			ResultSet rs = statement.executeQuery(query);
			if(rs.isBeforeFirst()) {
				rs.next();
				feedDto.setFeed_id(Integer.parseInt(rs.getString(1)));
				feedDto.setFeed_name(rs.getString(2));
				feedDto.setCountry_code(rs.getString(3));
				String projectSequence=rs.getString(4);
				if(!(projectSequence==null)) {
					feedDto.setProject_sequence(Integer.parseInt(projectSequence));
				}
			}

		}catch(SQLException e) {
			e.printStackTrace();
			
			throw new Exception("Exception occured while retrieving feed details");
		}
		
		return feedDto;
		
	}


	public static String generateSchema(Connection conn,String feed_name, String src_type,String runId,String table) throws Exception {
		
		if(src_type.equalsIgnoreCase("oracle")||src_type.equalsIgnoreCase("teradata")||src_type.equalsIgnoreCase("mssql")) {
			String query="select column_name,column_type from "+MetadataDBConstants.COLUMNSTATUSTABLE
					+" where feed_unique_name='"+feed_name+"' and run_id='"+runId+"' and table_name='"+table+"' order by column_pos";
			StringBuffer fieldList=new StringBuffer();
			StringBuffer schema=new StringBuffer();
			Statement statement=conn.createStatement();
			ResultSet rs=statement.executeQuery(query);
			if(rs.isBeforeFirst()) {
				while(rs.next()) {
					String column_name=rs.getString(1);
					String column_type=rs.getString(2);
					String query2="select tgt_data_typ from "+MetadataDBConstants.DATATYPELINKTABLE
							+" where src_db_typ='"+src_type
							+"' and tgt_db_typ='AVRO' and src_data_typ='"+column_type+"'";
					Statement statement2=conn.createStatement();
					ResultSet rs2=statement2.executeQuery(query2);
					if(rs2.isBeforeFirst()) {
						rs2.next();
						fieldList.append(column_name+"~"+rs2.getString(1).toLowerCase()+",");
					}
					else {
						fieldList.append(column_name+"~"+"string"+",");
					}
					
					
				}
				fieldList.setLength(fieldList.length()-1);
				schema.append("{ \"type\":\"record\",\"name\":\""+table+"\",\"fields\":[");
				for(String fields:fieldList.toString().split(",")) {
					schema.append("{\"name\":\""+fields.split("~")[0]+"\",\"type\":[\"null\",\""+fields.split("~")[1]+"\"]},");
					
				}
				schema.setLength(schema.length()-1);
				schema.append("]}");
				
				return schema.toString();
			}
			else {
				
				throw new Exception("columns not found");
			}
			
		}else if(src_type.equalsIgnoreCase("unix")) {
			
			String query="select column_name,column_type from "+MetadataDBConstants.COLUMNSTATUSTABLE
					+" where feed_unique_name='"+feed_name+"' and run_id='"+runId+"' and table_name='"+table+"' order by column_pos";
			StringBuffer fieldList=new StringBuffer();
			StringBuffer schema=new StringBuffer();
			Statement statement=conn.createStatement();
			ResultSet rs=statement.executeQuery(query);
			if(rs.isBeforeFirst()) {
				while(rs.next()) {
					String column_name=rs.getString(1);
					String column_type=rs.getString(2);
					fieldList.append(column_name.trim()+"~"+column_type.toLowerCase().trim()+",");
				}
				fieldList.setLength(fieldList.length()-1);
				schema.append("{ \"type\":\"record\",\"name\":\""+table+"\",\"fields\":[");
				for(String fields:fieldList.toString().split(",")) {
					schema.append("{\"name\":\""+fields.split("~")[0]+"\",\"type\":[\"null\",\""+fields.split("~")[1]+"\"]},");
					
				}
				schema.setLength(schema.length()-1);
				schema.append("]}");
				
				return schema.toString();
					
				}else {
					throw new Exception("columns not found");
				}
			
			
		}
		
		
		else {
			return null;
		}
		
		
	}


	public static String getSrcType(Connection conn,String feed_name) throws Exception {
		String query="select src_conn_type from "+MetadataDBConstants.CONNECTIONTABLE
				+" where src_conn_sequence=(select distinct l.src_conn_sequence from "+MetadataDBConstants.SRCTGTLINKTABLE
				+" l inner join "+MetadataDBConstants.FEEDTABLE
				+" f on l.feed_sequence=f.feed_sequence where f.feed_unique_name='"+feed_name+"')";
		Statement statement=conn.createStatement();
		ResultSet rs=statement.executeQuery(query);
		if(rs.isBeforeFirst()) {
			rs.next();
			String src_type=rs.getString(1);
			return src_type;
		}
		else {
			
			throw new Exception ("Exception occured while retrieving source type");
		}
		
	}


	public static String getTableList(Connection conn,String feed_name, String runId) throws Exception {
		
		String query="select distinct table_name from "+MetadataDBConstants.TABLESTATUS+
				" where feed_unique_name='"+feed_name+"' and run_id='"+runId+"'";
		Statement statement=conn.createStatement();
		ResultSet rs=statement.executeQuery(query);
		if(rs.isBeforeFirst()) {
			StringBuffer tableList=new StringBuffer();
			while(rs.next()) {
				tableList.append(rs.getString(1)+",");
			}
			tableList.setLength(tableList.length()-1);
			return tableList.toString();
		}
		else {
			throw new Exception("Tables not found");
		}
		
	}
	
	public static String updateNifiProcessgroupDetails(Connection conn, ExtractionDto extractDto,String src_type,String target_name ,String path,String date, String run_id,int index) throws SQLException{
		
		String deleteQuery="delete from "+MetadataDBConstants.NIFISTATUSTABLE+" where feed_unique_name='"+extractDto.getFeedDto().getFeed_name()
				+"' and run_id='"+run_id+"' and job_name='"+extractDto.getFeedDto().getFeed_name()+"_"+target_name+"_write"+"'";
		
		
		String insertQuery=MetadataDBConstants.INSERTQUERY.replace("{$table}", MetadataDBConstants.NIFISTATUSTABLE)
					.replace("{$columns}", "country_code,feed_id,feed_unique_name,run_id,nifi_pg,pg_type,extracted_date,project_sequence,job_type,job_name,status")
					.replace("{$data}",MetadataDBConstants.QUOTE+extractDto.getFeedDto().getCountry_code()+MetadataDBConstants.QUOTE+MetadataDBConstants.COMMA
							+extractDto.getFeedDto().getFeed_id()+MetadataDBConstants.COMMA
							+MetadataDBConstants.QUOTE+extractDto.getFeedDto().getFeed_name()+MetadataDBConstants.QUOTE+MetadataDBConstants.COMMA
							+MetadataDBConstants.QUOTE+run_id+MetadataDBConstants.QUOTE+MetadataDBConstants.COMMA
							+index+MetadataDBConstants.COMMA
							+MetadataDBConstants.QUOTE+src_type+MetadataDBConstants.QUOTE+MetadataDBConstants.COMMA
							+MetadataDBConstants.QUOTE+date+MetadataDBConstants.QUOTE+MetadataDBConstants.COMMA
							+extractDto.getFeedDto().getProject_sequence()+MetadataDBConstants.COMMA
							+MetadataDBConstants.QUOTE+"W"+MetadataDBConstants.QUOTE+MetadataDBConstants.COMMA
							+MetadataDBConstants.QUOTE+extractDto.getFeedDto().getFeed_name()+"_"+target_name+"_write"+MetadataDBConstants.QUOTE+MetadataDBConstants.COMMA
							+MetadataDBConstants.QUOTE+"running"+MetadataDBConstants.QUOTE);
			
			System.out.println("insert query is "+insertQuery);
			try {	
				Statement statement = conn.createStatement();
				statement.execute(deleteQuery);
				statement.execute(insertQuery);
				System.out.println("query executed");
			}catch (SQLException e) {
				e.printStackTrace();
				throw new SQLException("Execption occured while updating job status");
			}
			return "success";
							
		}
	
	public static String checkProcessGroupStatus(Connection conn, int index, String conn_type) throws SQLException{
		

		Date date = Calendar.getInstance().getTime();
		DateFormat formatter = new SimpleDateFormat("YYYYMMdd");
        String today = formatter.format(date);
		String query= "select status from "+ MetadataDBConstants.NIFISTATUSTABLE +" where nifi_pg="+index+" and extracted_date='"+today+"' and pg_type='"+conn_type
				+"' and job_type='W'";
		try {
			Statement statement=conn.createStatement();
			ResultSet rs = statement.executeQuery(query);
			if(rs.isBeforeFirst()) {
				while(rs.next()) {
					if(rs.getString(1).equalsIgnoreCase("RUNNING")) {
						return "Not Free";
					}
				}
		}else {
			return "Free";
		}
		}catch(SQLException e) {
			throw e;
		}
		return "Free";
		
	}


public static String insertMaterializationInfo(Connection conn,ExtractionDto extractDto, String src_type, String today, String runId) throws Exception{

	String insertQuery=MetadataDBConstants.INSERTQUERY.replace("{$table}", MetadataDBConstants.MATERIALIZATIONTABLE)
			.replace("{$columns}", "country_code,feed_id,feed_unique_name,target_sequence,run_id,extracted_date,mat_status,project_sequence")
			.replace("{$data}",MetadataDBConstants.QUOTE+extractDto.getFeedDto().getCountry_code()+MetadataDBConstants.QUOTE+MetadataDBConstants.COMMA
					+extractDto.getFeedDto().getFeed_id()+MetadataDBConstants.COMMA
					+MetadataDBConstants.QUOTE+extractDto.getFeedDto().getFeed_name()+MetadataDBConstants.QUOTE+MetadataDBConstants.COMMA
					+extractDto.getTargetDto().getTarget_id()+MetadataDBConstants.COMMA
					+MetadataDBConstants.QUOTE+runId+MetadataDBConstants.QUOTE+MetadataDBConstants.COMMA
					+MetadataDBConstants.QUOTE+today+MetadataDBConstants.QUOTE+MetadataDBConstants.COMMA
					+MetadataDBConstants.QUOTE+"To be Materialized"+MetadataDBConstants.QUOTE+MetadataDBConstants.COMMA
					+extractDto.getFeedDto().getProject_sequence());
	
	Statement statement=conn.createStatement();
	statement.execute(insertQuery);
					
	return "success";
}


public static String getDbList(Connection conn,String feed_name) throws Exception {
	String query=  "select db_name from "+MetadataDBConstants.DBPROPOGATIONTABLE+" h inner join "+MetadataDBConstants.FEEDTABLE+" f on h.feed_id=f.feed_sequence where f.feed_unique_name='"+feed_name+"'";
	StringBuffer dbList=new StringBuffer();
	Statement statement=conn.createStatement();
	ResultSet rs=statement.executeQuery(query);
	if(rs.isBeforeFirst()) {
		while(rs.next()) {
			dbList.append(rs.getString(1));
		}
		return dbList.toString();
	}
	else {
		
		throw new Exception("Database not found");
	}
	
	
	
}

}
