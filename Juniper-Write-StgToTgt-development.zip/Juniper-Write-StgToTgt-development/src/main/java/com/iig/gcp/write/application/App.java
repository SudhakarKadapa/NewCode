package com.iig.gcp.write.application;

import java.sql.Connection;
import java.sql.SQLException;

import com.iig.gcp.write.dao.juniperOnPremWriteDao;
import com.iig.gcp.write.dto.ExtractionDto;
import com.iig.gcp.write.nifi.NifiConfig;
import com.iig.gcp.write.util.MetadataDBConnectionUtils;



public class App 
{
    public static void main( String[] args ) throws SQLException
    {
    	String feed_name=args[0];
		String target_name=args[1];
		String runId=args[2];
		Connection conn=null;
		
		ExtractionDto extractDto=new ExtractionDto();
		try {
			conn= MetadataDBConnectionUtils.connectToMetadataDb();
			extractDto.setTargetDto(juniperOnPremWriteDao.getTargetObject(conn,target_name));
			extractDto.setFeedDto(juniperOnPremWriteDao.getFeedObject(conn,feed_name));
			NifiConfig.callNifi(conn, extractDto, feed_name,target_name, runId);
			
		}catch(Exception e) {
			e.printStackTrace();
			conn.close();
			System.exit(1);
		}
    }
}
