package com.iig.gcp.write.nifi;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;
import java.util.Random;
import java.util.UUID;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.iig.gcp.write.constant.NifiConstants;
import com.iig.gcp.write.dao.juniperOnPremWriteDao;
import com.iig.gcp.write.dto.ExtractionDto;




public class NifiConfig {
	
	static Properties prop = new Properties();
	static InputStream input = null;
	
	
	@SuppressWarnings("static-access")
	public static void callNifi(Connection conn,ExtractionDto extractDto,String feed_name,String target_name,String runId) throws Exception {
		
		input = new FileInputStream("/home/juniper/scripts/jars/write/config.properties");
	    prop.load(input);
		Date date = Calendar.getInstance().getTime();
		DateFormat formatter = new SimpleDateFormat("YYYYMMdd");
        String today = formatter.format(date);
        String path= extractDto.getFeedDto().getCountry_code()+"/"+extractDto.getFeedDto().getFeed_name()+"/"+today+"/"+runId;
        String src_type=juniperOnPremWriteDao.getSrcType(conn,feed_name);
        int index=0;
        String processGroupStatus="";
        String trigger_flag="N";
        	do {
    			Thread.currentThread().sleep(10000);
    			index=getRandomNumberInRange(1, Integer.parseInt(prop.getProperty("write.processor.count")));
    			processGroupStatus=juniperOnPremWriteDao.checkProcessGroupStatus(conn,index,src_type);
    			if(processGroupStatus.equalsIgnoreCase("FREE")) {
    				
    				updateExecuteSQLProcessor(feed_name, target_name, runId, index);
    				trigger_flag="Y";
    				
    			}
    			
    		}while(trigger_flag.equalsIgnoreCase("N"));
        	 JSONArray jsonArr=createJsonObject(conn,extractDto,feed_name,src_type,path,today,runId,index,target_name);
        	 invokeNifiFull(jsonArr,prop.getProperty("nifi.write.url"));
        

        
        
   	 String updateStatus=juniperOnPremWriteDao.updateNifiProcessgroupDetails(conn,extractDto,src_type,target_name,path, today, runId,index);
     if(updateStatus.equalsIgnoreCase("SUCCESS")) {
  	   if(!(extractDto.getTargetDto().getMaterialization_flag()==null||extractDto.getTargetDto().getMaterialization_flag().equalsIgnoreCase("N"))) {
  		   String insertMat=juniperOnPremWriteDao.insertMaterializationInfo(conn,extractDto,src_type,today,runId);
  		   if(insertMat.equalsIgnoreCase("success")) {
  			   System.out.println("Job executed successfully");
  		   }
  	   }
     }
		
	}
	
	private  static int getRandomNumberInRange(int min, int max) {

		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
			}
			Random r = new Random();
			return r.nextInt((max - min) + 1) + min;
	}

	@SuppressWarnings("unchecked")
	private static JSONArray createJsonObject(Connection conn,ExtractionDto extractDto,String feed_name, String src_type,String path,String date,String runId,int index,String target_name) throws Exception {
		
		JSONArray jsonArr=new JSONArray();
		String tableList=juniperOnPremWriteDao.getTableList(conn,feed_name,runId);
		final char ctrlA = '\u0001';  
		if(extractDto.getTargetDto().getTarget_type().equalsIgnoreCase("GCS")) {
			String gcsTarget=extractDto.getTargetDto().getTarget_project()+ctrlA+extractDto.getTargetDto().getService_account()+ctrlA+extractDto.getTargetDto().getTarget_bucket();	
			for(String table:tableList.split(",")) {
				JSONObject json =new JSONObject();
				String schema=juniperOnPremWriteDao.generateSchema(conn,feed_name,src_type,runId,table);
				json.put("schema", schema);
				json.put("table_name", table);
				json.put("src_type", src_type);
				json.put("target_type", extractDto.getTargetDto().getTarget_type());
				json.put("path", path);
				json.put("gcsTarget", gcsTarget);
				json.put("country", extractDto.getFeedDto().getCountry_code());
				json.put("feed_name", extractDto.getFeedDto().getFeed_name());
				json.put("feed_id", extractDto.getFeedDto().getFeed_id());
				json.put("date", date);
				json.put("run_id", runId);
				json.put("process_group", index);
				json.put("target_name", target_name);
				jsonArr.add(json);
			}
			
			
		}
		if(extractDto.getTargetDto().getTarget_type().equalsIgnoreCase("HDFS")) {
			
			
			
			String hdfsTarget=extractDto.getTargetDto().getTarget_knox_host()+ctrlA
					+extractDto.getTargetDto().getTarget_knox_port()+ctrlA
					+extractDto.getTargetDto().getTarget_hdfs_gateway()+ctrlA
					+extractDto.getTargetDto().getTarget_hdfs_path()+ctrlA
					+extractDto.getTargetDto().getTarget_user()+ctrlA
					+extractDto.getTargetDto().getTarget_password();
			for(String table:tableList.split(",")) {
				JSONObject json=new JSONObject();
				String schema=juniperOnPremWriteDao.generateSchema(conn,feed_name,src_type,runId,table);
				json.put("schema", schema);
				json.put("table_name", table);
				json.put("src_type", src_type);
				json.put("target_type", extractDto.getTargetDto().getTarget_type());
				json.put("partition_flag", extractDto.getTargetDto().getPartition_flag());
				json.put("path", path);
				json.put("hdfsTarget", hdfsTarget);
				json.put("country", extractDto.getFeedDto().getCountry_code());
				json.put("feed_name", extractDto.getFeedDto().getFeed_name());
				json.put("feed_id", extractDto.getFeedDto().getFeed_id());
				json.put("date", date);
				json.put("run_id", runId);
				json.put("process_group", index);
				json.put("target_name", target_name);
				if(extractDto.getTargetDto().getPartition_flag().equalsIgnoreCase("Y")) {
					if(table.contains(".")) {
						String targetDataPath=extractDto.getFeedDto().getCountry_code()+"/"
								+feed_name+"/data/"
								+"jnpr_"+feed_name+"_"+extractDto.getFeedDto().getCountry_code()+"_"+"prod.db"+"/"+table.split("\\.")[1];
						String targetMetadataPath=extractDto.getFeedDto().getCountry_code()+"/"
								+feed_name+"/metadata/"
								+"jnpr_"+feed_name+"_"+extractDto.getFeedDto().getCountry_code()+"_"+"prod.db"+"/"+table.split("\\.")[1];
						json.put("targetDataPath", targetDataPath);
						json.put("targetMetadataPath", targetMetadataPath);
					}else {
						String targetDataPath=extractDto.getFeedDto().getCountry_code()+"/"
								+feed_name+"/data/"
								+"jnpr_"+feed_name+"_"+extractDto.getFeedDto().getCountry_code()+"_"+"prod.db"+"/"+table;
						String targetMetadataPath=extractDto.getFeedDto().getCountry_code()+"/"
								+feed_name+"/metadata/"
								+"jnpr_"+feed_name+"_"+extractDto.getFeedDto().getCountry_code()+"_"+"prod.db"+"/"+table;
						json.put("targetDataPath", targetDataPath);
						json.put("targetMetadataPath", targetMetadataPath);
					}
					
				}
				if(extractDto.getTargetDto().getPartition_flag().equalsIgnoreCase("N")) {
					
					if(table.contains(".")) {
						String targetDataPath=extractDto.getFeedDto().getCountry_code()+"/"
								+feed_name+"/"+date
								+"/"+runId+"/data/"
								+"jnpr_"+feed_name+"_"+extractDto.getFeedDto().getCountry_code()+"_"+"prod"
								+"_"+runId+"_"+date+".db"+"/"+table.split("\\.")[1];
						String targetMetadataPath=extractDto.getFeedDto().getCountry_code()+"/"
								+feed_name+"/"+date
								+"/"+runId+"/metadata/"+table.split("\\.")[1];
						json.put("targetDataPath", targetDataPath);
						json.put("targetMetadataPath", targetMetadataPath);
					}else {
						String targetDataPath=extractDto.getFeedDto().getCountry_code()+"/"
								+feed_name+"/"+date
								+"/"+runId+"/data/"
								+"jnpr_"+feed_name+"_"+extractDto.getFeedDto().getCountry_code()+"_"+"prod"
								+"_"+runId+"_"+date
								+".db"+"/"+table;
						String targetMetadataPath=extractDto.getFeedDto().getCountry_code()+"/"
								+feed_name+"/"+date
								+"/"+runId+"/metadata/"+table;
						json.put("targetDataPath", targetDataPath);
						json.put("targetMetadataPath", targetMetadataPath);
					}
					
					
				}
				jsonArr.add(json);
			}
	
		}
		System.out.println(jsonArr.toJSONString());
		return jsonArr;
	}
	
	private static void invokeNifiFull(JSONArray arr,String  listenHttpUrl) throws UnsupportedOperationException, Exception {
		
		
		
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		@SuppressWarnings("rawtypes")
		Iterator it = arr.iterator();
		while (it.hasNext()) {
			JSONObject json=(JSONObject) it.next();
			HttpPost postRequest=new HttpPost(listenHttpUrl);
			StringEntity input = new StringEntity(json.toString());
			postRequest.setEntity(input); 
			HttpResponse response = httpClient.execute(postRequest);
			if(response.getStatusLine().getStatusCode()!=200) {
					System.out.println("Nifi listener problem"+response.getStatusLine().getStatusCode());
					throw new Exception("Nifi Not Running Or Some Problem In Sending HTTP Request"+response.getEntity().getContent().toString());
			}
			else {
				System.out.println("Nifi Triggered");
			}
		}
		
	}
	
	private static void updateExecuteSQLProcessor(String feed_name,String target_name,String run_id,int index) throws Exception {
		input = new FileInputStream("/home/juniper/scripts/jars/write/config.properties");
	    prop.load(input);
	    String varname="execute.sql.id."+index;
	    HttpEntity respEntity=null;
	    String processorId=prop.getProperty(varname);
	    System.out.println("processor id is "+processorId);
	    respEntity=getProcessorDetails(prop.getProperty("nifi.url"), prop.getProperty("nifi.processor.url").replace("${processorId}", processorId));
	    if (respEntity != null) {
			String content = EntityUtils.toString(respEntity);
			JSONObject processorJson = (JSONObject) new JSONParser().parse(content);
			JSONObject revision=(JSONObject) processorJson.get("revision");
			Long ver=(Long) revision.get("version");
			String version=String.valueOf(ver);
			String clientId=(String) revision.get("clientId");
			if(clientId == null || clientId.isEmpty()) {
				clientId=UUID.randomUUID().toString();
			}
			stopProcessor(processorId, version, clientId);
			updateProcessor(processorId, feed_name, target_name, run_id, index);
			startProcessor(processorId);
			
			
			
	    }
		
	}
	
	
	private static HttpEntity getProcessorDetails(String nifiUrl, String processorUrl) throws ClientProtocolException, IOException {
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		HttpGet httpGet = new HttpGet(nifiUrl + processorUrl);
		HttpResponse response = httpClient.execute(httpGet);
		HttpEntity respEntity = response.getEntity();
		return respEntity;

	}
	
	private static void stopProcessor(String id,String version, String clientId) throws Exception {
		
		input = new FileInputStream("/home/juniper/scripts/jars/write/config.properties");
	    prop.load(input);
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		

		StringEntity input = new StringEntity(NifiConstants.STOPPROCESSOR.replace("${id}", id)
					.replace("${version}", version).replace("${clientId}", clientId));

			input.setContentType("application/json;charset=UTF-8");
			HttpPut putRequest = new HttpPut(prop.getProperty("nifi.url")+ prop.getProperty("nifi.processor.url").replace("${processorId}", id));

			putRequest.setEntity(input);
			CloseableHttpResponse httpResponse = httpClient.execute(putRequest);
			if (httpResponse.getStatusLine().getStatusCode() != 200) {
				System.out.println(EntityUtils.toString(httpResponse.getEntity()));
				throw new Exception("exception occured while stoping processor");
			}
			else {
				System.out.println("processor with id "+id+" stopped ");
			}

		
	}
	
	
	private static void updateProcessor(String id,String feed_name,String target_name,String run_id,int index) throws Exception {
		
		HttpEntity respEntity=null;
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		input = new FileInputStream("/home/juniper/scripts/jars/write/config.properties");
	    prop.load(input);

		respEntity=getProcessorDetails(prop.getProperty("nifi.url"), prop.getProperty("nifi.processor.url").replace("${processorId}", id));
	    if (respEntity != null) {
			String content = EntityUtils.toString(respEntity);
			JSONObject processorJson = (JSONObject) new JSONParser().parse(content);
			JSONObject revision=(JSONObject) processorJson.get("revision");
			Long ver=(Long)revision.get("version");
			String version=String.valueOf(ver);
			String clientId=(String) revision.get("clientId");
			if(clientId == null || clientId.isEmpty()) {
				clientId=UUID.randomUUID().toString();
			}
			String job_name=(feed_name+"_"+target_name+"_write").toUpperCase();
			 StringEntity input = new StringEntity(NifiConstants.UPDATEEXECUTESQL.replace("${id}", id)
						.replace("${version}", version).replace("${clientId}", clientId).replace("${query}", NifiConstants.QUERY.replace("${feed_name}", feed_name)
								.replace("${run_id}", run_id).replace("${index}", String.valueOf(index)).replace("${job_name}", job_name)));
			
				input.setContentType("application/json;charset=UTF-8");
				HttpPut putRequest = new HttpPut(prop.getProperty("nifi.url")+"/"+ prop.getProperty("nifi.processor.url").replace("${processorId}", id));

				putRequest.setEntity(input);
				CloseableHttpResponse httpResponse = httpClient.execute(putRequest);
				if (httpResponse.getStatusLine().getStatusCode() != 200) {
					System.out.println(EntityUtils.toString(httpResponse.getEntity()));
					throw new Exception("exception occured while updating processor");
				}
				else {
					System.out.println("processor with id "+id+" updated ");
				}

		
	}
	   	}
	
	
private static void startProcessor(String id) throws Exception {
		
	HttpEntity respEntity=null;
	CloseableHttpClient httpClient = HttpClientBuilder.create().build();
	input = new FileInputStream("/home/juniper/scripts/jars/write/config.properties");
    prop.load(input);

	respEntity=getProcessorDetails(prop.getProperty("nifi.url"), prop.getProperty("nifi.processor.url").replace("${processorId}", id));
    if (respEntity != null) {
		String content = EntityUtils.toString(respEntity);
		JSONObject processorJson = (JSONObject) new JSONParser().parse(content);
		JSONObject revision=(JSONObject) processorJson.get("revision");
		Long ver=(Long)revision.get("version");
		String version=String.valueOf(ver);
		String clientId=(String) revision.get("clientId");
		if(clientId == null || clientId.isEmpty()) {
			clientId=UUID.randomUUID().toString();
		}
		StringEntity input = new StringEntity(NifiConstants.STARTPROCESSOR.replace("${id}", id)
				.replace("${version}", version).replace("${clientId}", clientId));

		input.setContentType("application/json;charset=UTF-8");
		HttpPut putRequest = new HttpPut(prop.getProperty("nifi.url")+ prop.getProperty("nifi.processor.url").replace("${processorId}", id));

		putRequest.setEntity(input);
		CloseableHttpResponse httpResponse = httpClient.execute(putRequest);
		if (httpResponse.getStatusLine().getStatusCode() != 200) {
			System.out.println(EntityUtils.toString(httpResponse.getEntity()));
			throw new Exception("exception occured while starting processor");
		}
		else {
			System.out.println("processor with id "+id+" started ");
		}

    }
		

		
		
	}

}
