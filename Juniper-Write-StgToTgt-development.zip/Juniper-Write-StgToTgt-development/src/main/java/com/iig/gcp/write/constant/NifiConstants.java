package com.iig.gcp.write.constant;

public class NifiConstants {

	
	public final static String STOPPROCESSOR="{\n" + 
			"  \"status\": {\n" + 
			"    \"runStatus\": \"STOPPED\"\n" + 
			"  },\n" + 
			"  \"component\": {\n" + 
			"    \"state\": \"STOPPED\",\n" + 
			"    \"id\": \"${id}\"\n" + 
			"  },\n" + 
			"  \"id\": \"${id}\",\n" + 
			"  \"revision\": {\n" + 
			"    \"version\": ${version},\n" + 
			"    \"clientId\": \"${clientId}\"\n" + 
			"  }\n" + 
			"}";
	
	public final static String UPDATEEXECUTESQL="{\n" + 
			"  \"status\": {\n" + 
			"    \"runStatus\": \"STOPPED\"\n" + 
			"  },\n" + 
			"  \"component\": {\n" + 
			"    \"state\": \"STOPPED\",\n" + 
			"    \"id\": \"${id}\",\n" + 
			"   \"config\": {\n"+
			"   \"properties\": {\n"+
			"   \"SQL select query\" : \"${query}\"\n" +
			"  }\n" + 
			"  }\n" +
            "  },\n" +
			"  \"id\": \"${id}\",\n" + 
			"  \"revision\": {\n" + 
			"    \"version\": ${version},\n" + 
			"	\"clientId\": \"${clientId}\" \n"+
			"  }\n" + 
			"}";
	
	public final static String QUERY="select feed_unique_name as feed_name,run_id as run_id,job_name as job_name ,status as status from JUNIPER_EXT_NIFI_STATUS where feed_unique_name='${feed_name}' and run_id='${run_id}' and nifi_pg= ${index} and upper(job_name)='${job_name}'";
	
	public final static String STARTPROCESSOR="{\n" + 
			"  \"status\": {\n" + 
			"    \"runStatus\": \"RUNNING\"\n" + 
			"  },\n" + 
			"  \"component\": {\n" + 
			"    \"state\": \"RUNNING\",\n" + 
			"    \"id\": \"${id}\"\n" + 
			"  },\n" + 
			"  \"id\": \"${id}\",\n" + 
			"  \"revision\": {\n" + 
			"    \"version\": ${version},\n" + 
			"    \"clientId\": \"${clientId}\"\n" + 
			"  }\n" + 
			"}";
}
