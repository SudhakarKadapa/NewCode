package com.iig.gcp.extraction.fileread.dto;

import java.util.ArrayList;



public class FileInfoDto {
	
	
	int feed_id;
	String dataPath;
	ArrayList<FileMetadataDto> fileMetadataArr;
	String project;
	String juniper_user;
	String conv_flag;
	String file_type;
	String file_delimiter;
	String quote_char;
	
	
	
	
	
	
	public String getFile_type() {
		return file_type;
	}
	public void setFile_type(String file_type) {
		this.file_type = file_type;
	}
	public String getFile_delimiter() {
		return file_delimiter;
	}
	public void setFile_delimiter(String file_delimiter) {
		this.file_delimiter = file_delimiter;
	}
	public String getQuote_char() {
		return quote_char;
	}
	public void setQuote_char(String quote_char) {
		this.quote_char = quote_char;
	}
	public String getConv_flag() {
		return conv_flag;
	}
	public void setConv_flag(String conv_flag) {
		this.conv_flag = conv_flag;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	
	public String getJuniper_user() {
		return juniper_user;
	}
	public void setJuniper_user(String juniper_user) {
		this.juniper_user = juniper_user;
	}
	public String getDataPath() {
		return dataPath;
	}
	public void setDataPath(String dataPath) {
		this.dataPath = dataPath;
	}
	
	public int getFeed_id() {
		return feed_id;
	}
	public void setFeed_id(int feed_id) {
		this.feed_id = feed_id;
	}
	public ArrayList<FileMetadataDto> getFileMetadataArr() {
		return fileMetadataArr;
	}
	public void setFileMetadataArr(ArrayList<FileMetadataDto> fileMetadataArr) {
		this.fileMetadataArr = fileMetadataArr;
	}
	
	

}
