package com.iig.gcp.extraction.fileread.nifi;

import java.io.IOException;
import java.sql.Connection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Random;
import java.util.UUID;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.iig.gcp.extraction.fileread.constant.NifiConstants;
import com.iig.gcp.extraction.fileread.dao.ExtractDao;
import com.iig.gcp.extraction.fileread.dto.ExtractDto;
import com.iig.gcp.extraction.fileread.dto.FileMetadataDto;


public class NifiConfig {
	
	@SuppressWarnings("static-access")
	public static String selectNifiProcessGroup(Connection conn,ExtractDto extractDto) throws Exception {
		
		
		int index=0;
		String trigger_flag="N";
		String controllerId="";
		String clientId="";
		String controllerVersion="";
		String controllerStatus="";
		String processorInfo="";
		HttpEntity respEntity=null;
		  
		
		
			
			  try {
				 do {
						
						Thread.currentThread().sleep(10000);
		    			index=getRandomNumberInRange(1, NifiConstants.NOOFUNIXPROCESSORS);
		    			String processGroupStatus=ExtractDao.checkProcessGroupStatus(conn,index,extractDto.getConnDto().getConn_type());
							
							 if(processGroupStatus.equalsIgnoreCase("FREE")) {
								
								NifiConstants constants=new NifiConstants();
								String varName="UNIXPROCESSGROUPURL"+index;
								String processGroupUrl = String.valueOf(NifiConstants.class.getDeclaredField(varName).get(constants));
								respEntity=getProcessGroupDetails(NifiConstants.NIFIURL, processGroupUrl);
								if (respEntity != null) {
									String content = EntityUtils.toString(respEntity);
									System.out.println(content);
									JSONObject controllerObj=getUnixControllerObject(content);
									 String controllerInfo=getControllerInfo(controllerObj);
									 controllerId=controllerInfo.split(",")[0];
									 clientId=controllerInfo.split(",")[1];
									 controllerVersion=controllerInfo.split(",")[2];
									 controllerStatus=controllerInfo.split(",")[3];
									 System.out.println("controller id,clientId, version and status are : "+controllerId+" "+clientId+" "+controllerVersion+" "+controllerStatus);
									 if(controllerStatus.equalsIgnoreCase("ENABLED")) {
										 processorInfo=processorFree(controllerObj);
										if(!processorInfo.equalsIgnoreCase("NOT FREE")) {
												System.out.println("using processgroup"+index);
												trigger_flag="Y";
												
											
										}
									}
								}
							}
						}while(trigger_flag.equalsIgnoreCase("N"));	
				
				
			}catch(Exception e) {
				e.printStackTrace();
				throw new Exception("Exception ocurred while retrieving Nifi process group details");
			}
			
			  return index+"---"+clientId+"---"+controllerId+"---"+processorInfo;
		}
	
	
	public static String callNifi(Connection conn,ExtractDto extractDto,String processGroupInfo,String runId) throws Exception{
		
		String delimiter=null;
		String quote_char=null;
		Date date = Calendar.getInstance().getTime();
		DateFormat formatter = new SimpleDateFormat("YYYYMMdd");
        String today = formatter.format(date);
		String index=processGroupInfo.split("---")[0];
		String clientId=processGroupInfo.split("---")[1];
		String controllerId=processGroupInfo.split("---")[2];
		String processorInfo=processGroupInfo.split("---")[3];
		NifiConstants constants=new NifiConstants();
		String varName="UNIXPROCESSGROUPURL"+index;
		String processGroupUrl = String.valueOf(NifiConstants.class.getDeclaredField(varName).get(constants));
		stopReferencingComponents(processorInfo, clientId);
		disableController(controllerId);
		if(extractDto.getFileInfoDto().getFile_delimiter().equalsIgnoreCase("COMMA")) {
			delimiter=",";
		}
		if(extractDto.getFileInfoDto().getFile_delimiter().equalsIgnoreCase("tab")) {
			delimiter="\t";
		}
		if(extractDto.getFileInfoDto().getFile_delimiter().equalsIgnoreCase("semicolon")) {
			delimiter=";";
		}
		if(extractDto.getFileInfoDto().getFile_delimiter().equalsIgnoreCase("pipe")) {
			delimiter="\\|";
		}
		
		if(extractDto.getFileInfoDto().getFile_delimiter().equalsIgnoreCase("@")) {
			delimiter="@";
		}
		
		if(extractDto.getFileInfoDto().getQuote_char().equalsIgnoreCase("DOUBLE QUOTE")) {
			quote_char="\"";
		}
		if(extractDto.getFileInfoDto().getQuote_char().equalsIgnoreCase("single quote")) {
			quote_char="'";
		}
		
		updateUnixController(delimiter, quote_char, controllerId);
		enableController(controllerId);
		startReferencingComponents(controllerId,processGroupUrl);
		String path=extractDto.getFeedDto().getCountry_code()+"/"+ extractDto.getFeedDto().getFeed_name()+"/"+today+"/"+runId+"/";
		JSONArray arr=createUnixJsonObject( conn,extractDto,index,today, runId);
		invokeNifiFull(arr,NifiConstants.UNIXLISTENER1);
		ExtractDao.updateNifiProcessgroupDetails(conn, extractDto, path, today, runId, index);
		return "success";
		
	
}
	
	
	private  static int getRandomNumberInRange(int min, int max) {

		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
			}
			Random r = new Random();
			return r.nextInt((max - min) + 1) + min;
	}
	
	private static HttpEntity getProcessGroupDetails(String nifiUrl, String processGroupUrl) throws ClientProtocolException, IOException {
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		HttpGet httpGet = new HttpGet(nifiUrl + processGroupUrl);
		HttpResponse response = httpClient.execute(httpGet);
		HttpEntity respEntity = response.getEntity();
		return respEntity;

	}
	
	@SuppressWarnings("rawtypes")
	private static JSONObject getUnixControllerObject(String content) throws ClientProtocolException, IOException, org.json.simple.parser.ParseException {
		
		JSONObject jsonObject = (JSONObject) new JSONParser().parse(content);
		JSONArray jsonArray = (JSONArray) jsonObject.get("controllerServices");
		Iterator i = jsonArray.iterator();
		while(i.hasNext()) {
			JSONObject controllerObject=(JSONObject) i.next();
			JSONObject controllerComponent = (JSONObject) controllerObject.get("component");
			String name= (String) controllerComponent.get("name");
			if(name.equalsIgnoreCase("csvreader")){
				System.out.println(name);
				return controllerObject;
			}
			
		}
		
		
		return null;

	}
	private static String getControllerInfo(JSONObject controllerJsonObject) throws Exception{
		
		
		String controllerId="";
		String controllerClientId="";
		String controllerVersion="";
		String controllerStatus="";
	
		controllerId=String.valueOf(controllerJsonObject.get("id"));
		JSONObject controllerRevision = (JSONObject) controllerJsonObject.get("revision");
		JSONObject controllerComponent=(JSONObject) controllerJsonObject.get("component");
		controllerClientId=String.valueOf(controllerRevision.get("clientId"));
		controllerVersion=String.valueOf(controllerRevision.get("version"));
		controllerStatus=String.valueOf(controllerComponent.get("state"));
		return controllerId+","+controllerClientId+","+controllerVersion+","+controllerStatus;
		
	}
	
	private static  String processorFree(JSONObject controllerJsonObject)
			throws ParseException, IOException, org.json.simple.parser.ParseException {
		
		int activeThreadCount=0;
		StringBuffer refComponents=new StringBuffer();
		JSONObject controllerComponent=(JSONObject)controllerJsonObject.get("component");
		JSONArray arrayOfReferencingComponents=(JSONArray)controllerComponent.get("referencingComponents");
		for(int i=0;i<arrayOfReferencingComponents.size();i++) {
			JSONObject refComp=(JSONObject)arrayOfReferencingComponents.get(i);
			String refCompId=String.valueOf(refComp.get("id"));
			JSONObject refCompRevision=(JSONObject)refComp.get("revision");
			String refCompVersion=String.valueOf(refCompRevision.get("version"));
			refComponents.append(refCompId+"~"+refCompVersion+",");
			JSONObject refCompComponent=(JSONObject)refComp.get("component");
			if(!String.valueOf(refCompComponent.get("activeThreadCount")).equals("0")) {
				activeThreadCount++;
			}else {
				System.out.println("No Active thread for processor "+refCompId);
			}
			
		}
		refComponents.setLength(refComponents.length()-1);
		if(activeThreadCount==0) {
			return refComponents.toString();
		}
		else {
			return "Not free";
		}

	}
	
	private static  void stopReferencingComponents(String processorInfo,String clientId) throws Exception {
		System.out.println("processor Info is "+processorInfo);
		for (String processor : processorInfo.split(",")) {
			String processorId = processor.split("~")[0];
			String processorVersion = processor.split("~")[1];
			stopProcessor(processorId, processorVersion, clientId);
		}
	}
	
	private static void stopProcessor(String id,String version, String clientId) throws Exception {
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		

		StringEntity input = new StringEntity(NifiConstants.STOPPROCESSOR.replace("${id}", id)
					.replace("${version}", version).replace("${clientId}", clientId));

			input.setContentType("application/json;charset=UTF-8");
			HttpPut putRequest = new HttpPut(NifiConstants.NIFIURL + NifiConstants.PROCESSORURL.replace("${id}", id));

			putRequest.setEntity(input);
			CloseableHttpResponse httpResponse = httpClient.execute(putRequest);
			if (httpResponse.getStatusLine().getStatusCode() != 200) {
				System.out.println(EntityUtils.toString(httpResponse.getEntity()));
				throw new Exception("exception occured while stoping processor");
			}
			else {
				System.out.println("processor with id "+id+" stopped ");
			}

		
	}
	private static void disableController(String controllerId) throws Exception {
		
		HttpEntity respEntity=null;
		String clientId="";
		String controllerVersion="";
		
		
		respEntity=getControllerServiceDetails(NifiConstants.NIFIURL, "nifi-api/controller-services/"+controllerId);
		if (respEntity != null) {
			String content = EntityUtils.toString(respEntity);
			String clientIdVersion=getClientId(content);
			clientId=clientIdVersion.split(",")[0];
			controllerVersion=clientIdVersion.split(",")[1];
			
		}
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		
		String DISABLECOMMAND=NifiConstants.DISABLECONTROLLERCOMMAND.replace("${clientid}", clientId).replace("${version}", controllerVersion).replace("${id}",controllerId);
		System.out.println("command is "+DISABLECOMMAND);
		StringEntity input = new StringEntity(
				DISABLECOMMAND);
		input.setContentType("application/json;charset=UTF-8");
		System.out.println(input.toString());
		HttpPut putRequest = new HttpPut(NifiConstants.NIFIURL + "nifi-api/controller-services/"+controllerId );
		putRequest.setEntity(input);

		CloseableHttpResponse httpResponse = httpClient.execute(putRequest);
		if (httpResponse.getStatusLine().getStatusCode() != 200) {
			System.out.println(httpResponse.getStatusLine().toString());
			System.out.println(EntityUtils.toString(httpResponse.getEntity()));
			throw new Exception("exception occured while disabling controller");
		}
		else {
			System.out.println("controller disabled");
		}

	}
	
	private static HttpEntity getControllerServiceDetails(String nifiUrl, String controllerServiceUrl) throws ClientProtocolException, IOException {
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		HttpGet httpGet = new HttpGet(nifiUrl + controllerServiceUrl);
		HttpResponse response = httpClient.execute(httpGet);
		HttpEntity respEntity = response.getEntity();
		return respEntity;

	}
	
	private static  String getClientId(String content) throws Exception {

		JSONObject jsonObject = (JSONObject) new JSONParser().parse(content);
		System.out.println("----->"+jsonObject.toJSONString());
		JSONObject jsonVersionObject = (JSONObject) jsonObject.get("revision");
		String version = jsonVersionObject.get("version").toString();
		Object clientID = jsonVersionObject.get("clientId");
		
		if(clientID == null) {
			clientID=UUID.randomUUID().toString();
		}
		
		return clientID + "," + version;

	}
	
	@SuppressWarnings("static-access")
	private static void updateUnixController(String delimiter,String quote_char,String controllerId) throws Exception {

		HttpEntity respEntity=null;
		String state="";
		String clientId="";
		String controllerVersion="";
		
		do {
			Thread.currentThread().sleep(5000);
			respEntity=getControllerServiceDetails(NifiConstants.NIFIURL, "nifi-api/controller-services/"+controllerId);
			if (respEntity != null) {
				String content = EntityUtils.toString(respEntity);
				state=getControllerState(content);
				if(state.equalsIgnoreCase("DISABLED")) {
					String controllerInfo=getClientId(content);
					clientId=controllerInfo.split(",")[0];
					controllerVersion=controllerInfo.split(",")[1];
					
				}
		}
		
	}while(!state.equalsIgnoreCase("DISABLED"));
		System.out.println("controller is now disabled");
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		StringEntity input=null;
		if(quote_char.equalsIgnoreCase("\"")) {
			 input = new StringEntity(NifiConstants.UPDATECSVREADERDOUBLEQUOTE.replace("${clientId}", clientId)
					.replace("${ver}", controllerVersion).replace("${contId}", controllerId)
					.replace("${valueSeparator}", delimiter)
					.replace("${quoteCharacter}", quote_char));
		}
		if(quote_char.equalsIgnoreCase("'")) {
			
			input = new StringEntity(NifiConstants.UPDATECSVREADERSINGLEQUOTE.replace("${clientId}", clientId)
					.replace("${ver}", controllerVersion).replace("${contId}", controllerId)
					.replace("${valueSeparator}", delimiter)
					.replace("${quoteCharacter}", quote_char));
			
		}
		

		input.setContentType("application/json;charset=UTF-8");
		HttpPut putRequest = new HttpPut(NifiConstants.NIFIURL + "nifi-api/controller-services/"+controllerId);

		putRequest.setEntity(input);
		CloseableHttpResponse httpResponse = httpClient.execute(putRequest);
		if (httpResponse.getStatusLine().getStatusCode() != 200) {
			System.out.println(EntityUtils.toString(httpResponse.getEntity()));
			throw new Exception("exception occured while updating controller");
		}

	}

	private  static String getControllerState(String content) throws org.json.simple.parser.ParseException {
		JSONObject jsonObject = (JSONObject) new JSONParser().parse(content);
		JSONObject controllerComponent = (JSONObject) jsonObject.get("component");
		String state = controllerComponent.get("state").toString();
		return state;
	}
	
	private static void enableController(String controllerId) throws Exception{
		
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		HttpEntity respEntity=null;
		String controllerInfo="";
		String clientId="";
		String controllerVersion="";
		respEntity=getProcessGroupDetails(NifiConstants.NIFIURL, "nifi-api/controller-services/"+controllerId);
		if (respEntity != null) {
			String content = EntityUtils.toString(respEntity);
			controllerInfo=getClientId(content);
			clientId=controllerInfo.split(",")[0];
			controllerVersion=controllerInfo.split(",")[1];
	}
		
			StringEntity input = new StringEntity(NifiConstants.ENABLECONTROLLER.replace("${clientId}", clientId)
					.replace("${ver}", controllerVersion).replace("${contId}", controllerId));
			input.setContentType("application/json;charset=UTF-8");
			HttpPut putRequest = new HttpPut(NifiConstants.NIFIURL + "nifi-api/controller-services/"+controllerId);

			putRequest.setEntity(input);
			CloseableHttpResponse httpResponse = httpClient.execute(putRequest);
			if (httpResponse.getStatusLine().getStatusCode() != 200) {
				System.out.println(EntityUtils.toString(httpResponse.getEntity()));
				throw new Exception("exception occured while enabling controller");
			}
			else {
				System.out.println("controller Enabling started");
			}
		}
	
	
	@SuppressWarnings("static-access")
	private static  void startReferencingComponents(String controllerId,String processGroupUrl)
			throws Exception {
		HttpEntity respEntity=null;
		String state="";
		String clientId="";
		
		do {
			Thread.currentThread().sleep(5000);
			respEntity=getControllerServiceDetails(NifiConstants.NIFIURL, "nifi-api/controller-services/"+controllerId);
			if (respEntity != null) {
				String content = EntityUtils.toString(respEntity);
				state=getControllerState(content);
			
		}
		
	}while(!state.equalsIgnoreCase("ENABLED"));
		System.out.println("controller is now enabled");
		respEntity=getProcessGroupDetails(NifiConstants.NIFIURL, processGroupUrl);
		if (respEntity != null) {
			String content = EntityUtils.toString(respEntity);
			JSONObject controllerObj=getUnixControllerObject(content);
			StringBuffer refComponents=new StringBuffer();
			JSONObject controllerComponent=(JSONObject)controllerObj.get("component");
			JSONArray arrayOfReferencingComponents=(JSONArray)controllerComponent.get("referencingComponents");
			for(int i=0;i<arrayOfReferencingComponents.size();i++) {
				JSONObject refComp=(JSONObject)arrayOfReferencingComponents.get(i);
				String refCompId=String.valueOf(refComp.get("id"));
				JSONObject refCompRevision=(JSONObject)refComp.get("revision");
				String refCompVersion=String.valueOf(refCompRevision.get("version"));
				refComponents.append(refCompId+"~"+refCompVersion+",");
		}
		refComponents.setLength(refComponents.length()-1);
		for(String processor:refComponents.toString().split(",")) {
			String processorId=processor.split("~")[0];
			String processorVersion=processor.split("~")[1];
			CloseableHttpClient httpClient = HttpClientBuilder.create().build();
			StringEntity input = new StringEntity(NifiConstants.STARTPROCESSOR.replace("${id}", processorId)
					.replace("${version}", processorVersion).replace("${clientId}", clientId));

			input.setContentType("application/json;charset=UTF-8");
			HttpPut putRequest = new HttpPut(NifiConstants.NIFIURL + NifiConstants.PROCESSORURL.replace("${id}", processorId));

			putRequest.setEntity(input);
			CloseableHttpResponse httpResponse = httpClient.execute(putRequest);
			if (httpResponse.getStatusLine().getStatusCode() != 200) {
				System.out.println(EntityUtils.toString(httpResponse.getEntity()));
				throw new Exception("exception occured while starting processor");
			}

		}

	}
	}
	@SuppressWarnings("unchecked")
	private static  JSONArray createUnixJsonObject(Connection conn,ExtractDto extractDto,String index,String date,String runId) throws Exception {

		JSONArray arr = new JSONArray();
		
		for(FileMetadataDto file: extractDto.getFileInfoDto().getFileMetadataArr()) {
			String field_metadata=generateSchema(file.getFile_name(),file.getField_list());
			String token_flag=ExtractDao.getTokenizationflag(conn,file.getFile_sequence());
			String token_cols=null;
			if(token_flag.equalsIgnoreCase("Y")) {
				 token_cols=ExtractDao.getTokenizationColumns(conn,file.getFile_sequence());
			}
			String key=ExtractDao.getTokenizationKey(conn,extractDto.getConnDto().getSys_seq(),extractDto.getFeedDto().getProject_sequence());
			
			JSONObject json=new JSONObject();
			json.put("token_flag", token_flag);
			json.put("token_cols", token_cols);
			json.put("token_key", key);
			json.put("process_group", index);
			json.put("project_sequence", extractDto.getFeedDto().getProject_sequence());
			json.put("feed_id", extractDto.getFeedDto().getFeed_id());
			json.put("file_sequence", file.getFile_sequence());
			json.put("file_name", file.getFile_name());
			String table_name=file.getFile_name();
			if(table_name.contains(".")) {
				table_name=table_name.split("\\.")[0];
			}
			table_name=table_name.replaceAll("\\?", "").replaceAll("\\*", "").replaceAll("[^a-zA-Z]+$", "");
			json.put("table_name", table_name);
			json.put("avro_conv_flg", file.getAvro_conv_flag());
			json.put("header_count", file.getHeader_count());
			json.put("trailer_count", file.getTrailer_count());
			json.put("field_list", field_metadata);
			json.put("date", date);
			json.put("feed_name", extractDto.getFeedDto().getFeed_name());
			json.put("country_code", extractDto.getFeedDto().getCountry_code());
			json.put("file_path", file.getFile_path());
			json.put("run_id", runId);
			json.put("date", date);
			
			arr.add(json);
			System.out.println(arr.toJSONString());
		}
	
		return arr;
	}
	
	


	private static String generateSchema(String tableName,String field_list) {
		// TODO Auto-generated method stub
		StringBuffer schema= new StringBuffer();
		schema.append("{ \"type\":\"record\",\"name\":\"$\",\"fields\":[");
		for(String fields:field_list.split(",")) {
			schema.append("{\"name\":\""+fields.split("~")[0].trim()+"\",\"type\":[\"null\",\""+fields.split("~")[1]+"\"]},");
			
		}
		schema.setLength(schema.length()-1);
		schema.append("]}");
		
		
		
		
		return schema.toString();
	}
	
	@SuppressWarnings("rawtypes")
	private static void invokeNifiFull(JSONArray arr,String listenHttpUrl) throws UnsupportedOperationException, Exception {
		
		
				
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		Iterator it = arr.iterator();
		while (it.hasNext()) {
			JSONObject json=(JSONObject) it.next();
			HttpPost postRequest=new HttpPost(listenHttpUrl);
			StringEntity input = new StringEntity(json.toString());
			postRequest.setEntity(input); 
			HttpResponse response = httpClient.execute(postRequest);
			if(response.getStatusLine().getStatusCode()!=200) {
					System.out.println("Nifi listener problem"+response.getStatusLine().getStatusCode());
					throw new Exception("Nifi Not Running Or Some Problem In Sending HTTP Request"+response.getEntity().getContent().toString());
			}
			else {
				System.out.println("Nifi Triggered");
			}
		}
	}
	

		
	
		
	

}
