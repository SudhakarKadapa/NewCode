package com.iig.gcp.extraction.fileread.util;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;


public class MetadataDBConnectionUtils {
	
	
	
	public static Connection connectToMetadataDb() throws Exception{
		
		Properties prop = new Properties();
		InputStream input = null;
		input = new FileInputStream("/home/juniper/scripts/jars/unix/config.properties");
        prop.load(input);
        Class.forName(prop.getProperty("databaseDriver"));
		String content = EncryptUtils.readFile(prop.getProperty("master.key.path"));
		String connectionUrl = prop.getProperty("oracle.jdbc.url").replaceAll("#orcl_ip", prop.getProperty("oracle.ip.port.sid"));
		byte[] base_pwd=org.apache.commons.codec.binary.Base64.decodeBase64(prop.getProperty("oracle.encrypt.pwd"));
		String orcl_decoded_pwd=EncryptUtils.decryptText(base_pwd, EncryptUtils.decodeKeyFromString(content));
		Connection conn = DriverManager.getConnection(connectionUrl, prop.getProperty("oracle.user.name"),
				orcl_decoded_pwd);
		return conn;
		
		
		
	}
	
	
	
}


