package com.iig.gcp.extraction.fileread.constant;

//import org.json.simple.JSONArray;


public class NifiConstants {

	
	public final static  String NIFIURL="http://35.211.207.161:9090/";
	public final static String NIFINSTANCEIP="35.211.207.161";
	
	public final static int NOOFUNIXPROCESSORS=3;
	public final static String UNIXPROCESSGROUPURL1="nifi-api/flow/process-groups/0a5635d8-fd1e-1424-0000-000053f25907/controller-services";
	public final static String UNIXPROCESSGROUPURL2="nifi-api/flow/process-groups/0e2b3320-02e3-15a4-ffff-ffffb525a057/controller-services";
	public final static String UNIXPROCESSGROUPURL3="nifi-api/flow/process-groups/0e2b337e-02e3-15a4-ffff-ffff9b9b5e57/controller-services";																			
	public final static String UNIXLISTENER1="http://35.211.207.161:8087/contentListener";
	
	
	public final static String DISABLECONTROLLERCOMMAND="{\"revision\":{\"clientId\":\"${clientid}\",\"version\":${version}},\"component\":{\"id\":\"${id}\",\"state\":\"DISABLED\"}}";
	public final static String PROCESSORURL="nifi-api/processors/${id}";
	public final static String STOPPROCESSOR="{\n" + 
			"  \"status\": {\n" + 
			"    \"runStatus\": \"STOPPED\"\n" + 
			"  },\n" + 
			"  \"component\": {\n" + 
			"    \"state\": \"STOPPED\",\n" + 
			"    \"id\": \"${id}\"\n" + 
			"  },\n" + 
			"  \"id\": \"${id}\",\n" + 
			"  \"revision\": {\n" + 
			"    \"version\": ${version},\n" + 
			"    \"clientId\": \"${clientId}\"\n" + 
			"  }\n" + 
			"}";
	public final static String STARTPROCESSOR="{\n" + 
			"  \"status\": {\n" + 
			"    \"runStatus\": \"RUNNING\"\n" + 
			"  },\n" + 
			"  \"component\": {\n" + 
			"    \"state\": \"RUNNING\",\n" + 
			"    \"id\": \"${id}\"\n" + 
			"  },\n" + 
			"  \"id\": \"${id}\",\n" + 
			"  \"revision\": {\n" + 
			"    \"version\": ${version},\n" + 
			"    \"clientId\": \"${clientId}\"\n" + 
			"  }\n" + 
			"}";
	
	public final static String STOPPROCESSOR2="{\n" + 
			"  \"status\": {\n" + 
			"    \"runStatus\": \"STOPPED\"\n" + 
			"  },\n" + 
			"  \"component\": {\n" + 
			"    \"state\": \"STOPPED\",\n" + 
			"    \"id\": \"${id}\"\n" + 
			"  },\n" + 
			"  \"id\": \"${id}\",\n" + 
			"  \"revision\": {\n" + 
			"    \"version\": ${version},\n" + 
			"	\"clientId\": \"\" \n"+
			"  }\n" + 
			"}";
	
	public final static String UPDATECSVREADERDOUBLEQUOTE="{\"revision\":{\"clientId\":\"${clientId}\",\"version\":${ver}},\"component\":{\"id\":\"${contId}\",\"state\":\"DISABLED\", \"properties\":{\"Value Separator\":\"${valueSeparator}\",\"Quote Character\":\"\\${quoteCharacter}\"}}}";
	public final static String UPDATECSVREADERSINGLEQUOTE="{\"revision\":{\"clientId\":\"${clientId}\",\"version\":${ver}},\"component\":{\"id\":\"${contId}\",\"state\":\"DISABLED\", \"properties\":{\"Value Separator\":\"${valueSeparator}\",\"Quote Character\":\"${quoteCharacter}\"}}}";
	
	public final static String ENABLECONTROLLER="{\"revision\":{\"clientId\":\"${clientId}\",\"version\":${ver}},\"component\":{\"id\":\"${contId}\",\"state\":\"ENABLED\"}}";
	
	
}
