package com.iig.gcp.extraction.fileread.application;

import java.sql.Connection;
import java.sql.SQLException;

import com.iig.gcp.extraction.fileread.dao.ExtractDao;
import com.iig.gcp.extraction.fileread.dto.ExtractDto;
import com.iig.gcp.extraction.fileread.nifi.NifiConfig;
import com.iig.gcp.extraction.fileread.util.MetadataDBConnectionUtils;


public class App 
{
    public static void main( String[] args )
    {
    	String feed_name=args[0];
		String runId=args[1];
		
		ExtractDto extractDto = new ExtractDto();
		Connection conn=null;
		try {
			
			conn= MetadataDBConnectionUtils.connectToMetadataDb();
			extractDto.setConnDto(ExtractDao.getConnectionObject(conn,feed_name));
			extractDto.setFeedDto(ExtractDao.getFeedObject(conn,feed_name,extractDto.getConnDto().getConn_type()));
			String fileList=extractDto.getFeedDto().getFileList();
			extractDto.setFileInfoDto(ExtractDao.getFileInfoObject(conn,fileList,extractDto.getFeedDto().getFeed_id()));
			String processGroupInfo=NifiConfig.selectNifiProcessGroup(conn, extractDto);
			String status=NifiConfig.callNifi(conn,extractDto, processGroupInfo, runId);
			if(status.equalsIgnoreCase("success")) {
				System.out.println("Extraction job started");
			}
	
			
		}catch(Exception e) {
			e.printStackTrace();
			return;
		}finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
    }
}
