package com.iig.gcp.extraction.fileread.dto;

public class ConnectionDto {
	
	
	String conn_name;
	String conn_type;
	int connId;
	String system;
	String project;
	String juniper_user;
	int sys_seq;
	int proj_seq;
	int drive_seq;
	
		
	
	public int getDrive_seq() {
		return drive_seq;
	}

	public void setDrive_seq(int drive_seq) {
		this.drive_seq = drive_seq;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}
	
	public String getJuniper_user() {
		return juniper_user;
	}
	public void setJuniper_user(String juniper_user) {
		this.juniper_user = juniper_user;
	}
	public int getSys_seq() {
		return sys_seq;
	}
	public void setSys_seq(int sys_seq) {
		this.sys_seq = sys_seq;
	}
	public int getProj_seq() {
		return proj_seq;
	}
	public void setProj_seq(int proj_seq) {
		this.proj_seq = proj_seq;
	}
	
	
	public int getConnId() {
		return connId;
	}
	public void setConnId(int connId) {
		this.connId = connId;
	}
	
	
	
	
	public String getConn_name() {
		return conn_name;
	}
	public void setConn_name(String conn_name) {
		this.conn_name = conn_name;
	}
	public String getConn_type() {
		return conn_type;
	}
	public void setConn_type(String conn_type) {
		this.conn_type = conn_type;
	}
	
	public String getSystem() {
		return system;
	}
	public void setSystem(String system) {
		this.system = system;
	}

}
