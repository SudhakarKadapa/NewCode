package com.iig.gcp.extraction.fileread.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.iig.gcp.extraction.fileread.constant.MetadataDBConstants;
import com.iig.gcp.extraction.fileread.dto.ConnectionDto;
import com.iig.gcp.extraction.fileread.dto.ExtractDto;
import com.iig.gcp.extraction.fileread.dto.FeedDto;
import com.iig.gcp.extraction.fileread.dto.FileInfoDto;
import com.iig.gcp.extraction.fileread.dto.FileMetadataDto;
import com.iig.gcp.extraction.fileread.util.EncryptUtils;

public class ExtractDao {
	
	
	public static ConnectionDto getConnectionObject(Connection conn,String feed_name) throws Exception {
		
		
		int connId=0;
		ConnectionDto connDto=new ConnectionDto();
		try {
			 connId=getConnectionId(conn,feed_name);
		}catch(Exception e) {
			e.printStackTrace();
			throw new Exception ("Exception ocurred while fetching source connection Id");
		}
		
		String query="select src_conn_type,drive_sequence,system_sequence from "+MetadataDBConstants.CONNECTIONTABLE+ " where src_conn_sequence="+connId;
			
				Statement statement=conn.createStatement();
				ResultSet rs=statement.executeQuery(query);
				if(rs.isBeforeFirst()) {
					rs.next();
					connDto.setConn_type(rs.getString(1));
					connDto.setDrive_seq(rs.getInt(2));
					connDto.setSys_seq(Integer.parseInt(rs.getString(3)));
					
				
				}
			
			return connDto;
		
		
	}
	
	public static int getConnectionId (Connection conn,String feed_name) throws Exception {

		int connectionId=0;
		String query="select src_conn_sequence from "+MetadataDBConstants.FEEDSRCTGTLINKTABLE+" where feed_sequence=(select feed_sequence from "
		+MetadataDBConstants.FEEDTABLE+" where feed_unique_name='"+feed_name+"')";
		Statement statement=conn.createStatement();
		ResultSet rs = statement.executeQuery(query);
		if(rs.isBeforeFirst()) {

			rs.next();
			connectionId=rs.getInt(1);

		}
		return connectionId;

	}
	
	
	public static FeedDto getFeedObject(Connection conn,String feed_name,String src_type) throws Exception{
		
		

		FeedDto feedDto=new FeedDto();

		String query="select feed_sequence,feed_unique_name,country_code,project_sequence from "+MetadataDBConstants.FEEDTABLE
				+ " where feed_unique_name='"+feed_name+"'";
		

		try {
			Statement statement=conn.createStatement();
			ResultSet rs = statement.executeQuery(query);
			if(rs.isBeforeFirst()) {
				rs.next();
				feedDto.setFeed_id(Integer.parseInt(rs.getString(1)));
				feedDto.setFeed_name(rs.getString(2));
				feedDto.setCountry_code(rs.getString(3));
				String projectSequence=rs.getString(4);
				if(!(projectSequence==null)) {
					feedDto.setProject_sequence(Integer.parseInt(projectSequence));
				}
			}

		}catch(SQLException e) {
			e.printStackTrace();
			throw new Exception("Exception occured while retrieving feed details");
		}
		
		
		StringBuffer fileList=new StringBuffer();
		String query3="select file_sequence from "+MetadataDBConstants.FILEDETAILSTABLE+
					" where feed_sequence="+feedDto.getFeed_id();
			try {
				Statement statement=conn.createStatement();
				ResultSet rs = statement.executeQuery(query3);
				if(rs.isBeforeFirst()) {
					while(rs.next()) {
						fileList.append(rs.getString(1)+",");
					}
				}
			}catch(SQLException e) {
				e.printStackTrace();
				throw new Exception("Exception occured while fetching table information of the feed");
			}
			fileList.setLength(fileList.length()-1);
			feedDto.setFileList(fileList.toString());
		
		return feedDto;

	
	}
	
	
	public static FileInfoDto getFileInfoObject(Connection conn, String fileList,int feed_id) throws Exception{
		
		FileInfoDto fileInfoDto= new FileInfoDto();
		String query1="select distinct file_type,file_delimiter,quote_char from "+MetadataDBConstants.FILEDETAILSTABLE+
				" where feed_sequence="+feed_id;
		Statement statement=conn.createStatement();
		ResultSet rs1=statement.executeQuery(query1);
		if(rs1.isBeforeFirst()) {
			rs1.next();
			fileInfoDto.setFile_type(rs1.getString(1));
			fileInfoDto.setFile_delimiter(rs1.getString(2));
			fileInfoDto.setQuote_char(rs1.getString(3));
			
		}
		ArrayList<FileMetadataDto> fileMetadataArr=new ArrayList<FileMetadataDto>();
		int count=0;
		String[] fileIds=fileList.split(",");
	
			for(String fileId:fileIds) {
				StringBuffer fieldList=new StringBuffer();
				FileMetadataDto fileMetadataDto= new FileMetadataDto();
				String query="select file_path,file_name,header_count,trailer_count,"
						+ "avro_conv_flg,bus_dt_format,bus_dt_loc,bus_dt_start,"
						+ "count_loc,count_start,count_length from "+MetadataDBConstants.FILEDETAILSTABLE+" where file_sequence="+fileId;
				ResultSet rs = statement.executeQuery(query);
				if(rs.isBeforeFirst()) {
					rs.next();
					fileMetadataDto.setFile_sequence(Integer.parseInt(fileId));
					fileMetadataDto.setFile_path(rs.getString(1));
					fileMetadataDto.setFile_name(rs.getString(2));
					fileMetadataDto.setHeader_count(rs.getString(3));
					fileMetadataDto.setTrailer_count(rs.getString(4));
					String flag=rs.getString(5);
					if(flag.equalsIgnoreCase("Y")) {
						count++;
						fileMetadataDto.setAvro_conv_flag(flag);
					}else {
						fileMetadataDto.setAvro_conv_flag(flag);
					}
					fileMetadataDto.setBus_dt_format(rs.getString(6));
					fileMetadataDto.setBus_dt_loc(rs.getString(7));
					if(!(rs.getString(8)==null || rs.getString(8).isEmpty())) {
						fileMetadataDto.setBus_dt_start(Integer.parseInt(rs.getString(8)));
					}
					
					fileMetadataDto.setCount_loc(rs.getString(9));
					if(!(rs.getString(10)==null || rs.getString(10).isEmpty())) {
						fileMetadataDto.setCount_start(Integer.parseInt(rs.getString(10)));
					}
					if(!(rs.getString(11)==null || rs.getString(11).isEmpty())) {
						
						fileMetadataDto.setCount_legnth(Integer.parseInt(rs.getString(11)));
					}
					

				}


				String query2="select field_name,field_data_type from "+MetadataDBConstants.FIELDDETAILSTABLE
						+" where file_sequence="+fileId+" order by field_pos";


				ResultSet rs2 = statement.executeQuery(query2);
				if(rs2.isBeforeFirst()) {
					while(rs2.next()) {
						fieldList.append(rs2.getString(1)+"~");
						fieldList.append(rs2.getString(2)+",");
					}
				if(!(fieldList==null))
					fieldList.setLength(fieldList.length()-1);
					fileMetadataDto.setField_list(fieldList.toString());


				}

				fileMetadataArr.add(fileMetadataDto);

			}
		
		fileInfoDto.setFileMetadataArr(fileMetadataArr);
		if(count!=0) {
			fileInfoDto.setConv_flag("Y");
		}else {
			fileInfoDto.setConv_flag("N");
		}
		return fileInfoDto;
	}
	
	
	public static String checkProcessGroupStatus( Connection conn,int index, String conn_type) throws Exception{
		

		
		String query= "select status from "+ MetadataDBConstants.NIFISTATUSTABLE +" where nifi_pg="+index+" and pg_type='"+conn_type
				+"' and job_type='R'";
		
			Statement statement=conn.createStatement();
			ResultSet rs = statement.executeQuery(query);
			if(rs.isBeforeFirst()) {
				while(rs.next()) {
					if(rs.getString(1).equalsIgnoreCase("RUNNING")) {
						return "Not Free";
					}
				}
		}else {
			return "Free";
		}
		
		return "Free";
		
	}
	
	public static void updateNifiProcessgroupDetails(Connection conn, ExtractDto extractDto,String path,String date, String run_id,String index) throws SQLException{
		
		String deleteQuery="delete from "+MetadataDBConstants.NIFISTATUSTABLE+ " where feed_unique_name='"+extractDto.getFeedDto().getFeed_name()
				+"' and run_id='"+run_id+"' and job_type='R'";
		

		Statement statement = conn.createStatement();
		statement.execute(deleteQuery);
		
		
		String insertQuery=MetadataDBConstants.INSERTQUERY.replace("{$table}", MetadataDBConstants.NIFISTATUSTABLE)
				.replace("{$columns}", "country_code,feed_id,feed_unique_name,run_id,nifi_pg,pg_type,extracted_date,project_sequence,job_type,job_name,status")
				.replace("{$data}",MetadataDBConstants.QUOTE+extractDto.getFeedDto().getCountry_code()+MetadataDBConstants.QUOTE+MetadataDBConstants.COMMA
						+extractDto.getFeedDto().getFeed_id()+MetadataDBConstants.COMMA
						+MetadataDBConstants.QUOTE+extractDto.getFeedDto().getFeed_name()+MetadataDBConstants.QUOTE+MetadataDBConstants.COMMA
						+MetadataDBConstants.QUOTE+run_id+MetadataDBConstants.QUOTE+MetadataDBConstants.COMMA
						+index+MetadataDBConstants.COMMA
						+MetadataDBConstants.QUOTE+extractDto.getConnDto().getConn_type()+MetadataDBConstants.QUOTE+MetadataDBConstants.COMMA
						+MetadataDBConstants.QUOTE+date+MetadataDBConstants.QUOTE+MetadataDBConstants.COMMA
						+extractDto.getFeedDto().getProject_sequence()+MetadataDBConstants.COMMA
						+MetadataDBConstants.QUOTE+"R"+MetadataDBConstants.QUOTE+MetadataDBConstants.COMMA
						+MetadataDBConstants.QUOTE+extractDto.getFeedDto().getFeed_name()+"_read"+MetadataDBConstants.QUOTE+MetadataDBConstants.COMMA
						+MetadataDBConstants.QUOTE+"running"+MetadataDBConstants.QUOTE);
		
			 
			statement.execute(insertQuery);
			
		
		
						
	}

	public static String getTokenizationflag(Connection conn, int file_sequence) throws Exception {
		
		System.out.println("file swq--->"+file_sequence);
		String query="select FIELD_TOKENIZATION from "+MetadataDBConstants.FIELDDETAILSTABLE+" where file_sequence="+file_sequence;
		Statement statement=conn.createStatement();
		ResultSet rs=statement.executeQuery(query);
		if(rs.isBeforeFirst()) {
			while(rs.next()) {
				if(rs.getString(1).equalsIgnoreCase("Y")) {
					return "Y";
				}
			}
		}
		return "N";
		
	}

	public static String getTokenizationColumns(Connection conn, int file_sequence) throws Exception {
		
		StringBuffer colList=new StringBuffer();
		String query="select field_pos from "+MetadataDBConstants.FIELDDETAILSTABLE+" where file_sequence="+file_sequence+
				" and upper(field_tokenization)='Y'";
		Statement statement=conn.createStatement();
		ResultSet rs=statement.executeQuery(query);
		if(rs.isBeforeFirst()) {
			while(rs.next()) {
				colList.append(rs.getString(1)+",");
				}
			}
		colList.setLength(colList.length()-1);
		return colList.toString();
		}

	public static String getTokenizationKey(Connection conn, int sys_seq, int project_sequence) throws Exception{
		
		String query="select key_value from "+MetadataDBConstants.KEYTABLE+" where system_sequence="+sys_seq
				+" and project_sequence="+project_sequence;
		byte[] key=null;
		Statement statement=conn.createStatement();
		ResultSet rs=statement.executeQuery(query);
		if(rs.isBeforeFirst()) {
			rs.next();
			key=rs.getBytes(1);
		}
		return EncryptUtils.decryptKey(key);
		
	}
		
		
	
}
	

