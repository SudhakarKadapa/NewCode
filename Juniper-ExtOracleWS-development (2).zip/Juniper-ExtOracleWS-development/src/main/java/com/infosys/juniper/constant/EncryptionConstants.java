package com.infosys.juniper.constant;

public class EncryptionConstants {
	
	
	public static final String ENCRYPTIONSERVICEURL = "http://35.185.47.113:8087/submit";

}
